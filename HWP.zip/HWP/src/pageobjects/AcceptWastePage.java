package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="AcceptWastePage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class AcceptWastePage {

	@TextType()
	@JavascriptBy(jspath = "return document.querySelectorAll('lightning-input')[1].shadowRoot.querySelector('input')")
	public WebElement AcceptQtyRec;
	@ChoiceListType()
	@FindBy(xpath = "//div[4]/div/div/div/div/div/div//select")
	public WebElement QtyRecMeasure;
	@ChoiceListType()
	@FindBy(xpath = "//div[5]/div[6]//select[contains(@class,'slds-select')]")
	public WebElement HandlingCode;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save']")
	public WebElement save;
	@ChoiceListType()
	@FindBy(xpath = "//select[contains(@class,'slds-select')]")
	public WebElement RefusalReason;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Refuse']")
	public WebElement refuse;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='Click to Show Edit Shipping Information (click to expand)']")
	public WebElement CorrectionExpand;
	@BooleanType()
	@FindBy(xpath = "//div[contains(@class,'cRegistryAccordionSection')]//span/label/span[1]")
	public WebElement DangerousGoodsCheck;
	@BooleanType()
	@FindBy(xpath = "//label[normalize-space(.)='I am partially refusing this waste']/span[1]")
	public WebElement iAmPartiallyRefusingThisWaste;
	@TextType()
	@FindBy(xpath = "//*[contains(text(),'Quantity Received')]/preceding::*[input[contains(@class,'slds-input')]]")
	public WebElement QtyRefused;
			
}
