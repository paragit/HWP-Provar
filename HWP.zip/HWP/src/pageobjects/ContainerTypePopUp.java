package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ContainerTypePopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ContainerTypePopUp {

	@ChoiceListType()
	@FindBy(xpath = "//label[text()='Container Type']/parent::div//select")
	public WebElement containerType;
	@TextType()
	@FindBy(xpath = "//label[text()='Other, please specify']/following::div[1]//input")
	public WebElement specifyOther;
	@TextType()
	@FindBy(xpath = "//label[text()='Size']/following::div[1]//input")
	public WebElement size;
	@TextType()
	@FindBy(xpath = "//label[text()='How many']/following::div[1]//input")
	public WebElement howMany;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Save']")
	public WebElement save;
	
			
}
