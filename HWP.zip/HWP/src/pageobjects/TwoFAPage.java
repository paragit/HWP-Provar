package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="TwoFAPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class TwoFAPage {

	@BooleanType()
	@FindBy(xpath = "//label[normalize-space(.)='Email me at hmarksr_u940d@cguf.site']/span[1]")
	public WebElement emailMeAtHmarksrU940DCgufSite;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Next >']")
	public WebElement next;
	@BooleanType()
	@FindBy(xpath = "//label[contains(normalize-space(.),'Text me at ***-***-') and contains(@class,'slds-radio__label')]/span[1]")
	public WebElement _FA_Text;
	@BooleanType()
	@FindBy(xpath = "//label[starts-with(normalize-space(.),'Text me at ***-***-') and contains(@class,'slds-radio__label')]/span[1]")
	public WebElement TextRadio;
			
}
