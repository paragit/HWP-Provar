package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ProgramSelectionPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ProgramSelectionPage {

	@TextType()
	@FindBy(xpath = "//div[contains(@class,'AccountName')]/span")
	public WebElement accountName;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'MainHeader')]/span")
	public WebElement programsHeader;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'cRegistryManagePrograms')]/p")
	public WebElement manageProgramsText;
	@LinkType()
	@FindBy(xpath = "//p[text()='Hazardous Waste']/parent::div//a[@class='black']")
	public WebElement unregisteredIcon;
	@LinkType()
	@FindBy(xpath = "//p[text()='Hazardous Waste']/parent::div//a[@class='darkish-green']")
	public WebElement registeredIcon;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'cRegistryHomeSummary')]/parent::div/child::p")
	public WebElement registeredProgramText;
	@LinkType()
	@FindBy(xpath = "//a[@data-program='Tires']")
	public WebElement tiresIcon;
			
}
