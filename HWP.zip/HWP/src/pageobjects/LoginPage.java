package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LoginPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LoginPage {

	@FindBy(xpath = "//label[text()='Email']/parent::div/following-sibling::div/descendant::input")
	@TextType()
	public WebElement Email;
	@TextType()
	@FindBy(xpath = "//label[text()='Password']/parent::div/following-sibling::div//input")
	public WebElement password;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Sign In']")
	public WebElement signIn;
			
}
