package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="AddUserPopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class AddUserPopUp {

	@TextType()
	@FindBy(xpath = "//label[text()='Email']/parent::div/parent::div//input")
	public WebElement email;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Continue']")
	public WebElement continue_;
	@TextType()
	@FindBy(xpath = "//label[text()='First Name']/parent::div/parent::div//input")
	public WebElement firstName;
	@TextType()
	@FindBy(xpath = "//label[text()='Last Name']/parent::div/parent::div//input")
	public WebElement lastName;
	@TextType()
	@FindBy(xpath = "//label[text()='Job Title']/parent::div/parent::div//input")
	public WebElement jobTitle;
	@TextType()
	@FindBy(xpath = "//label[text()='Business Phone Number']/parent::div/parent::div//input")
	public WebElement businessPhoneNumber;
			
}
