package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ActivityDetails"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ActivityDetails {

	@TextType()
	@FindBy(xpath = "//div[text()='Activity Type']/following::div[1]//strong")
	public WebElement activityType;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//label[text()='Is this waste being processed under a Waste ECA?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement questionValidation;
	@TextType()
	@FindBy(xpath = "(//div[@class='numberInput'])[1]/following::span[1][@class='errorTextMessage']")
	public WebElement previousYearValidation;
	@TextType()
	@FindBy(xpath = "(//div[@class='numberInput'])[2]/following::span[1][@class='errorTextMessage']")
	public WebElement currentYearValidation;
	@TextType()
	@FindBy(xpath = "//select/following::span[@class='errorTextMessage']")
	public WebElement unitsValidation;
	@TextType()
	@FindBy(xpath = "//span[text()='Yes']")
	public WebElement yes;
	@TextType()
	@FindBy(xpath = "//label[text()='ECA Number']/parent::div/following-sibling::div//input")
	public WebElement ecaNumber;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste Class']/parent::div/following-sibling::div//input")
	public WebElement wasteClass;
	@TextType()
	@FindBy(xpath = "//label[text()='Primary Characterization']/parent::div/following-sibling::div//input")
	public WebElement primaryCharacterization;
	@TextType()
	@FindBy(xpath = "(//div[@class='numberInput'])[1]//input")
	public WebElement previousYearQuantity;
	@TextType()
	@FindBy(xpath = "(//div[@class='numberInput'])[2]//input")
	public WebElement currentYearQuantity;
	@ChoiceListType()
	@FindBy(xpath = "//select")
	public WebElement units;
	@TextType()
	@FindBy(xpath = "//label[text()='ECA Number']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement ecaNumberValidation;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Waste Management Method is required']")
	public WebElement wasteManagementValidation;
	@ChoiceListType()
	@FindBy(xpath = "//label[text()='Waste Management Method']/parent::div/following-sibling::div//select")
	public WebElement wasteManagementMethod;
	@TextType()
	@FindBy(xpath = "//div[@data-aura-class='cRegistryRadioGroup']//span[@class='errorTextMessage']")
	public WebElement disposalQuestionValidation;
	@ChoiceListType()
	@FindBy(xpath = "//div[@data-aura-class='cRegistryHWP_OnsiteActivityAnnualQuantities']//select")
	public WebElement disposalUnits;
			
}
