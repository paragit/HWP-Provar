package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="WasteStreamDetails"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class WasteStreamDetails {

	@ButtonType()
	@FindBy(xpath = "//button[text()='Edit']")
	public WebElement editWasteStream;
	@LinkType()
	@FindBy(xpath = "//div[text()='Facility Name']/following::div[1]//a")
	public WebElement viewFacilityName;
	@TextType()
	@FindBy(xpath = "//div[text()='Waste Class']/following::div[1]")
	public WebElement wasteClass;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Characterization']/following::div[1]")
	public WebElement primaryCharacterization;
	@TextType()
	@FindBy(xpath = "//div[text()='Physical State']/following::div[1]")
	public WebElement physicalState;
	@TextType()
	@FindBy(xpath = "//div[text()='Waste Type']/following::div[1]")
	public WebElement wasteType;
	@TextType()
	@FindBy(xpath = "//div[text()='Hazardous Waste Number']/following::div[1]")
	public WebElement hazardousWasteNumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Specific Gravity']/following::div[1]")
	public WebElement specificGravity;
	@TextType()
	@FindBy(xpath = "//div[text()='Waste Description']/following::div[1]")
	public WebElement wasteDescription;
	@TextType()
	@FindBy(xpath = "//div[text()='Waste stream and description of generating process']/following::div[1]")
	public WebElement wasteStreamDescription;
	@TextType()
	@FindBy(xpath = "//div[text()='Status']/following::div[1]")
	public WebElement status;
			
}
