package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ActivityDetailsShortTermStorage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ActivityDetailsShortTermStorage {

	@TextType()
	@FindBy(xpath = "//label[text()='Amount of waste stored']/parent::div/parent::div//input")
	public WebElement amountWasteStored;
	@ChoiceListType()
	@FindBy(xpath = "//label[text()='Units']/parent::div/parent::div//select")
	public WebElement units;
	@TextType()
	@FindBy(xpath = "//label[text()='When did you begin storing the waste?']/parent::div/parent::div//input")
	public WebElement wasteStoringDate;
	@TextType()
	@FindBy(xpath = "//label[text()='Reason for storage of waste past 90 day period']/parent::div/parent::div//textarea")
	public WebElement wasteStorageReason;
	@TextType()
	@FindBy(xpath = "//label[text()='Will the amount of waste stored change of time']/parent::div/parent::div//span[text()='Yes']")
	public WebElement changeOfTimeYes;
	@TextType()
	@FindBy(xpath = "//label[text()='Anticipated accumulation rate']/parent::div/parent::div//input")
	public WebElement anticipatedAccumulationRate;
	@TextType()
	@FindBy(xpath = "//label[text()='Maximum amount to be stored']/parent::div/parent::div//input")
	public WebElement maximumAmountStored;
	@TextType()
	@FindBy(xpath = "//label[text()='Will the amount of waste stored change of time']/parent::div/parent::div//span[text()='No']")
	public WebElement amountWasteStoredNo;
	@ChoiceListType()
	@FindBy(xpath = "//label[text()='Anticipated manner of disposal of waste']/parent::div/parent::div//select")
	public WebElement aniticipatedMannerWasteDisposal;
	@LinkType()
	@FindBy(xpath = "//a[contains(text(),'Add Container Type')]")
	public WebElement addContainerType;
	@LinkType()
	@FindBy(xpath = "//a[text()='Remove']")
	public WebElement remove;
	@LinkType()
	@FindBy(xpath = "//a[text()='Edit']")
	public WebElement editContainerType;
	@TextType()
	@FindBy(xpath = "//label[text()='Is waste stored in a secured area?']/parent::div/parent::div//span[text()='Yes']")
	public WebElement safetyQuestion1Yes;
	@TextType()
	@FindBy(xpath = "//label[text()='Is the waste storage drum(s)/tank(s) labelled?']/parent::div/parent::div//span[text()='Yes']")
	public WebElement safetyQuestion2Yes;
	@TextType()
	@FindBy(xpath = "//label[text()='Will a leak or spill be contained?']/parent::div/parent::div//span[text()='Yes']")
	public WebElement safetyQuestion3Yes;
	@TextType()
	@FindBy(xpath = "//label[text()='Do you have a contingency plan in the event of a spill?']/parent::div/parent::div//span[text()='Yes']")
	public WebElement safetyQuestion4Yes;
	@TextType()
	@FindBy(xpath = "//label[text()='Is the storage area/facility routinely inspected?']/parent::div/parent::div//span[text()='Yes']")
	public WebElement safetyQuestion5Yes;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//label[text()='Amount of waste stored']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement amountWasteStoredValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Units']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement unitsValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='When did you begin storing the waste?']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement wasteStoringDateValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Reason for storage of waste past 90 day period']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement reasonStorageValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Will the amount of waste stored change of time']/parent::div/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement amountWasteStoredChangeTime;
	@TextType()
	@FindBy(xpath = "//label[text()='Anticipated manner of disposal of waste']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement aniticipatedMannerDisposalValidation;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'cRegistryHWP_ShortTermStorageContainerDetails')]/following::span[1][@class='errorTextMessage']")
	public WebElement containerTypeValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Is waste stored in a secured area?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement safetyQuestion1Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Is the waste storage drum(s)/tank(s) labelled?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement safetyQuestion2Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Will a leak or spill be contained?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement safetyQuestion3Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Do you have a contingency plan in the event of a spill?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement safetyQuestion4Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Is the storage area/facility routinely inspected?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement safetyQuestion5Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Is waste stored in a secured area?']/parent::div/parent::div//span[text()='No']")
	public WebElement safetyQuestion1No;
			
}
