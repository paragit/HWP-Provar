package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="CarrierSignPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class CarrierSignPage {

	@BooleanType()
	@FindBy(xpath = "//span/label/span[contains(@class,'slds-checkbox_faux')]")
	public WebElement CarrierConfirm;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Confirm']")
	public WebElement confirm;
			
}
