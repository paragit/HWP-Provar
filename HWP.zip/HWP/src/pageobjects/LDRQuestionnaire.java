package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRQuestionnaire"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRQuestionnaire {

	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//label[text()='Is your waste stream being shipped out of Ontario to a facility not listed on the HWN list of recycling facilities?']/following::span[@class='errorTextMessage'][1]")
	public WebElement LDRQuestion1Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Are you unsure of any applicable exemptions or where your waste stream will be managed?']/following::span[@class='errorTextMessage'][1]")
	public WebElement LDRQuestion2Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Is your waste stream being shipped out of Ontario to a facility not listed on the HWN list of recycling facilities?']/following::span[1]//input")
	public WebElement LDRQuestion1Yes;
	@TextType()
	@FindBy(xpath = "//input[@id='nonHWINFacilityNo']")
	public WebElement LDRQuestion1No;
	@TextType()
	@FindBy(xpath = "//input[@id='unsureOfExemptionsYes']")
	public WebElement LDRQuestion2Yes;
	@TextType()
	@FindBy(xpath = "//input[@id='unsureOfExemptionsNo']")
	public WebElement LDRQuestion2No;
			
}
