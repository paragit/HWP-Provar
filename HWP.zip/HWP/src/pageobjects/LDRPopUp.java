package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRPopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRPopUp {

	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='I am not sure, continue to LDR Questionnaire']")
	public WebElement continueToLDRQuestionnaire;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Continue to LDR Notification Form']")
	public WebElement continueToLDRNotificationForm;
			
}
