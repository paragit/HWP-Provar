package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="CarrierConfirmationPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class CarrierConfirmationPage {

	@BooleanType()
	@FindBy(xpath = "//label/span[contains(@class,'slds-checkbox_faux')]")
	public WebElement CConfirm;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Confirm']")
	public WebElement confirm;
			
}
