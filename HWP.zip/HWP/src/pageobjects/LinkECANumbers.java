package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LinkECANumbers"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LinkECANumbers {

	@TextType()
	@FindBy(xpath = "//input[@type='text']")
	public WebElement searchECANumber;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Search']")
	public WebElement search;
	@TextType()
	@FindBy(xpath = "//span[text()='0001102531']")
	public WebElement ECASearch;
	@LinkType()
	@FindBy(xpath = "//a[text()='Add to List']")
	public WebElement addToList;
	@LinkType()
	@FindBy(xpath = "//a[text()='Edit']")
	public WebElement edit;
	@LinkType()
	@FindBy(xpath = "//a[text()='Remove']")
	public WebElement remove;
	@BooleanType()
	@FindBy(xpath = "//span[text()='I hereby confirm that I am authorized to link these ECA Numbers to my Registry Account on behalf of the organization(s) listed above.']")
	public WebElement confirmationCheckbox;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Link ECA Numbers']")
	public WebElement linkECANumbers;
			
}
