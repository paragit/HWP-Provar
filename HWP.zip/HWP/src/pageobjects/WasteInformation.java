package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="WasteInformation"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class WasteInformation {

	@TextType()
	@FindBy(xpath = "//label[text()='Waste Description']/parent::div//lightning-formatted-text")
	public WebElement wasteDescription;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//label[text()='Is your waste aqueous or non-aqueous?']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement wasteInformationQuestion1Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Will the alternate treatment standards be used to meet LDR requirements?']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement wasteInformationQuestion2Validation;
	@TextType()
	@FindBy(xpath = "//label[text()='Is the waste a soil or soil mixture? Or is the waste a debris or debris mixture?']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement wasteInformationQuestion3Validation;
	@TextType()
	@FindBy(xpath = "//span[text()='Aqueous']")
	public WebElement aqueous;
	@TextType()
	@FindBy(xpath = "//span[text()='Yes']")
	public WebElement Yes;
	@TextType()
	@FindBy(xpath = "//span[text()='Debris / Debris Mixture']")
	public WebElement debris;
	@TextType()
	@FindBy(xpath = "//span[@class='errorTextMessage']")
	public WebElement debrisDescriptionValidation;
	@TextType()
	@FindBy(xpath = "//textarea")
	public WebElement debrisDescription;
	@TextType()
	@FindBy(xpath = "//span[text()='Soil / Soil Mixture']")
	public WebElement soilMixture;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='Back to Dashboard']")
	public WebElement backToDashboard;
			
}
