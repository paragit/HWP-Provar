package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRNotificationPopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRNotificationPopUp {

	@LinkType()
	@FindBy(xpath = "//div[text()='Land Disposal Restriction (LDR)']/parent::div//a")
	public WebElement cancel;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Back to Waste Stream']")
	public WebElement backToWasteStream;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Continue to LDR Notification Form']")
	public WebElement continueToLDRNotificationForm;
	
			
}
