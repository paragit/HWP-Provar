package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="AddWasteStream"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class AddWasteStream {

	@TextType()
	@FindBy(xpath = "//label[text()='Facility Name']/parent::div/following-sibling::div[1]//input")
	public WebElement facilityName;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//label[text()='Facility Name']/ancestor::form//span[contains(@class,'error')]")
	public WebElement facilityNameValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste Class']/ancestor::form//span[contains(@class,'error')]")
	public WebElement wasteClassValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Physical State']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement physicalStateValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste Description']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement wasteDescriptionValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste stream and description of generating process']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement wasteStreamDescriptionValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste Class']/ancestor::form//input")
	public WebElement wasteClass;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste Type']/ancestor::form//input")
	public WebElement wasteType;
	@TextType()
	@FindBy(xpath = "//label[text()='Primary Characterization']/ancestor::form//input")
	public WebElement primaryCharacterization;
	@TextType()
	@FindBy(xpath = "//label[text()='Hazardous Waste Number']/ancestor::form//input")
	public WebElement hazardousWasteNumber;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste Description']/parent::div/parent::div//textarea")
	public WebElement wasteDescription;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste stream and description of generating process']/parent::div/parent::div//textarea")
	public WebElement wasteStreamDescription;
	@ChoiceListType()
	@FindBy(xpath = "//select")
	public WebElement physicalState;
	@TextType()
	@FindBy(xpath = "//label[text()='Specific Gravity']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement specificGravityValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Specific Gravity']/parent::lightning-input//input")
	public WebElement specificGravity;
			
}
