package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ReviewOnSiteWasteActivity"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ReviewOnSiteWasteActivity {

	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Submission Status')]/following::div//strong")
	public WebElement submissionStatus;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Company Name')]/following::div[1]//strong")
	public WebElement companyName;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Facility Name')]/following::div[1]//strong")
	public WebElement facilityName;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Generator Number')]/following::div[1]//strong")
	public WebElement generatorNumber;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Address')]/following::div[1]//strong")
	public WebElement address;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Latitude')]/following::div[1]//strong")
	public WebElement latitude;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Longitude')]/following::div[1]//strong")
	public WebElement longitude;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'   Description')]/following::div[1]//strong")
	public WebElement facilityDescription;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'  Name')]/following::div[1]//strong")
	public WebElement name;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Job Title')]/following::div[1]//strong")
	public WebElement jobTitle;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Email')]/following::div[1]//strong")
	public WebElement email;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Primary Phone Number')]/following::div[1]//strong")
	public WebElement primaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Secondary Phone Number')]/following::div[1]//strong")
	public WebElement secondaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Waste Class')]/following::div[1]//strong")
	public WebElement wasteClass;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Waste Type')]/following::div[1]//strong")
	public WebElement wasteType;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Primary Characterization')]/following::div[1]//strong")
	public WebElement primaryCharacterization;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Physical State')]/following::div[1]//strong")
	public WebElement physicalState;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Specific Gravity')]/following::div[1]//strong")
	public WebElement specificGravity;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Waste Description')]/following::div[1]//strong")
	public WebElement wasteDescription;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Waste stream and description of generation process')]/following::div[1]//strong")
	public WebElement wasteStream;
	@ButtonType()
	@FindBy(xpath = "//span[contains(text(),'Waste Stream')]/parent::div/parent::div//button[text()='Edit']")
	public WebElement editWasteStream;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Amount of waste stored')]/following::div[1]//strong")
	public WebElement amountWasteStored;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'When did you begin storing the waste?')]/following::div[1]//strong")
	public WebElement wasteStoringDate;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Reason for storage of waste past 90 day period')]/following::div[1]//strong")
	public WebElement wasteStorageReason;
	@ButtonType()
	@FindBy(xpath = "//span[contains(text(),'Waste Storage')]/parent::div/parent::div//button[text()='Edit']")
	public WebElement editWasteStorage;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Will the amount of waste stored change of time')]/following::div[1]//strong")
	public WebElement wasteStoredQuestion;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Anticipated accumulation rate')]/following::div[1]//strong")
	public WebElement anticipatedAccumulationRate;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Maximun amount to be stored')]/following::div[1]//strong")
	public WebElement maximumAmountStored;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Anticipated manner of disposal of waste')]/following::div[1]//strong")
	public WebElement anticipatedMannerOfDisposal;
	@ButtonType()
	@FindBy(xpath = "//span[contains(text(),'Waste Accumulation and Disposal')]/parent::div/parent::div//button[text()='Edit']")
	public WebElement editWasteAccumulation;
			
}
