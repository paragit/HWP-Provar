package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ActivityTypeInformationPopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ActivityTypeInformationPopUp {

	@LinkType()
	@FindBy(xpath = "//div[text()='Facility and Activity Type Information']/parent::div//a[text()='Cancel']")
	public WebElement cancel;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Continue']")
	public WebElement continue_;
	
			
}
