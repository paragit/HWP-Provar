package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="AdditionalECANumberDetails"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class AdditionalECANumberDetails {

	@ButtonType()
	@FindBy(xpath = "//div[contains(@class, 'active') and contains(@class, 'open') and (contains(@class, 'forceModal') or contains(@class, 'uiModal'))][last()]//button")
	public WebElement save;
	@TextType()
	@FindBy(xpath = "//label[text()='Email']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement emailValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Phone Number']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement primaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//label[text()='Email']/parent::div/parent::div//input")
	public WebElement email;
	@TextType()
	@FindBy(xpath = "//label[text()='Phone Number']/parent::div/parent::div//input")
	public WebElement phoneNumber;
	@TextType()
	@FindBy(xpath = "//label[text()='Phone Extension']/parent::div/parent::div//input")
	public WebElement phoneExtension;
	@LinkType()
	@FindBy(xpath = "//a[text()='Cancel']")
	public WebElement cancel;
			
}
