package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="CarrierInfoPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class CarrierInfoPage {

	@TextType()
	@FindBy()
	public WebElement RegNum;
	@ChoiceListType()
	@JavascriptBy(jspath = "return document.querySelector('div:nth-child(2) > div > div > div > div > div > div > div > div > div > select')")
	public WebElement Province_State;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save']")
	public WebElement save;
	@TextType()
	@FindBy(xpath = "//label[normalize-space(.)='Registration Number']//following::input[@maxlength='10']")
	public WebElement RegNum1;
			
}
