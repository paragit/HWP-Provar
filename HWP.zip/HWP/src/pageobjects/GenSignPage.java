package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="GenSignPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class GenSignPage {

	@BooleanType()
	@FindBy(xpath = "//label/span[contains(@class,'slds-checkbox_faux')]")
	public WebElement GenConfirm;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Confirm']")
	public WebElement confirm;
	@TextType()
	@FindBy(xpath = "//input[contains(@class,'slds-input') and @placeholder='Enter search terms here']")
	public WebElement Carriersearch;
			
}
