package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="Registry Facility"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class AddFacility {

	@BooleanType()
	@FindBy(xpath = "//span[text()='I hereby confirm that the facility information specified above is accurate.']/preceding-sibling::span")
	public WebElement attestation;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Save']")
	public WebElement save;
	@TextType()
	@FindBy(xpath = "//label[text()='Facility Name']/parent::div/following-sibling::div/span[@class='errorTextMessage']")
	public WebElement facilityNameValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='How long will this facility be generating waste?']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement wasteGenerationFacilityValidation;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Street is required']")
	public WebElement locationStreetValidation;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Once you log a waste activity for this facility, ')]/following-sibling::div[1]//label[text()='City']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement locationCityValidation;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Once you log a waste activity for this facility, ')]/following-sibling::div[1]//label[text()='Zip Code']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement locationPostalCodeValidation;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Once you log a waste activity for this facility, ')]/following-sibling::div[1]//label[text()='Latitude']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement locationLatitudeValidation;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Once you log a waste activity for this facility, ')]/following-sibling::div[1]//label[text()='Longitude']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement locationLongitudeValidation;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Once you log a waste activity for this facility, ')]/following-sibling::div[1]//span[text()='Community']/parent::label/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement locationCommunityValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='Street']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement mailingStreetValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='City']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement mailingCityValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='Postal Code']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement mailingPostalCodeValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='First Name']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement primaryFirstNameValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Last Name']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement primaryLastNameValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Job Title']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement primaryJobTitleValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Email']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement primaryEmailValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Primary Phone Number']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement primaryPhoneNumberValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Additional_Information']/following::div[2]//label[text()='NAICS Code']/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement NAICSCodeValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Additional_Information']/following::div[2]//label[text()='1.  Is your facility an approved Ontario Liquid Industrial/Hazardous Waste Receiver facility?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement additionalQuestionOneValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Additional_Information']/following::div[2]//label[text()='2.  Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement additionalQuestionTwoValidation;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Additional_Information']/following::div[2]//label[text()='3. Is your facility a contaminated facility located in Ontario, and all waste generated  is a result of activities carried out at the facility for the purpose of remediating contaminated soil or other contaminated materials located in, on, or under the site?']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement additionaQuestionThreeValidation;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Long term']/preceding::span[1]")
	public WebElement longTerm;
	@TextType()
	@FindBy(xpath = "//label[text()='How often will this facility be shipping waste off site?']/parent::div/parent::div//span[@class='errorTextMessage']")
	public WebElement wasteGenerationLongTermValidation;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Short term (specify end date below)']/preceding::span[1]")
	public WebElement shortTerm;
	@TextType()
	@FindBy(xpath = "//span[text()='Short term (specify end date below)']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement wasteGenerationShortTermValidation;
	@BooleanType()
	@FindBy(xpath = "//label[text()='1.  Is your facility an approved Ontario Liquid Industrial/Hazardous Waste Receiver facility?']/parent::div/following-sibling::div[1]//span[text()='Yes, enter the corresponding Environmental Compliance Approval Number']/preceding::span[1]")
	public WebElement additionalQuestionOneYes;
	@TextType()
	@FindBy(xpath = "//label[text()='1.  Is your facility an approved Ontario Liquid Industrial/Hazardous Waste Receiver facility?']/parent::div/parent::div/following::div[1]//span[@class='errorTextMessage']")
	public WebElement additionaQuestionOneYesValidation;
	@BooleanType()
	@FindBy(xpath = "//label[text()='2.  Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/parent::div/following-sibling::div[1]//span[text()='Yes, enter the corresponding Environmental Compliance Approval Number']/preceding::span[1]")
	public WebElement additionalQuestionTwoYes;
	@TextType()
	@FindBy(xpath = "//label[text()='2.  Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/parent::div/parent::div/following::div[1]//span[@class='errorTextMessage']")
	public WebElement additionalQuestionTwoYesValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Facility Name']/following::div[1]//input")
	public WebElement facilityName;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Regularly (more than once per year)']/preceding-sibling::span")
	public WebElement regularly;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//label[text()='Street']/following::div[1]//input")
	public WebElement locationStreet;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//label[text()='City']/following::div[1]//input")
	public WebElement locationCity;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//label[text()='Zip Code']/following::div[1]//input")
	public WebElement locationPostalCode;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//label[text()='Latitude']/following::div[1]//input")
	public WebElement locationLatitude;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//label[text()='Longitude']/following::div[1]//input")
	public WebElement locationLongitude;
	@TextType()
	@FindBy(xpath = "//label[text()='Description (Optional)']/following::div[1]//textarea")
	public WebElement locationDescription;
	@ChoiceListType()
	@FindBy(xpath = "//span[text()='Community']/following::div[1]//select")
	public WebElement locationCommunity;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='Street']/following::div[1]//input")
	public WebElement mailingStreet;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='City']/following::div[1]//input")
	public WebElement mailingCity;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='Postal Code']/following::div[1]//input")
	public WebElement mailingPostalCode;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='First Name']/following::div[1]//input")
	public WebElement primaryFirstName;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Last Name']/following::div[1]//input")
	public WebElement primaryLastName;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Job Title']/following::div[1]//input")
	public WebElement primaryJobTitle;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Email']/following::div[1]//input")
	public WebElement primaryEmail;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Primary Phone Number']/following::div[1]//input")
	public WebElement primaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "(//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Phone Extension'])[1]/following::div[1]//input")
	public WebElement primaryPhoneExtension;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Secondary Phone Number']/following::div[1]//input")
	public WebElement secondaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "(//div[@id='Section_Primary_Contact']/following::div[2]//label[text()='Phone Extension'])[2]/following::div[1]//input")
	public WebElement secondaryPhoneExtension;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='First Name']/following::div[1]//input")
	public WebElement alternateFirstContact;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Last Name']/following::div[1]//input")
	public WebElement alternateLastName;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Job Title']/following::div[1]//input")
	public WebElement alternateJobTitle;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Email']/following::div[1]//input")
	public WebElement alternateEmail;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Primary Phone Number']/following::div[1]//input")
	public WebElement alternatePrimaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Secondary Phone Number']/following::div[1]//input")
	public WebElement alternateSecondaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "(//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Phone Extension'])[1]/following::div[1]//input")
	public WebElement alternatePrimaryPhoneExtension;
	@TextType()
	@FindBy(xpath = "(//div[@id='Section_Alternate_Contact']/following::div[2]//label[text()='Phone Extension'])[2]/following::div[1]//input")
	public WebElement alternateSecondaryPhoneExtension;
	@TextType()
	@FindBy(xpath = "//label[text()='NAICS Code']/parent::div//input")
	public WebElement NAICSCode;
	@TextType()
	@FindBy(xpath = "//span[text()='Soybean farming']")
	public WebElement NAICSCodeValue;
	@TextType()
	@FindBy(xpath = "//label[text()='Industry']/following::div[1]")
	public WebElement industryNAICSCode;
	@TextType()
	@FindBy(xpath = "(//label[text()='NAICS Code (Optional)'])[1]/parent::div//input")
	public WebElement NAICSCodeOptional;
	@TextType()
	@FindBy(xpath = "//span[text()='Wheat farming']")
	public WebElement NAICSCodeOptionalValue;
	@TextType()
	@FindBy(xpath = "(//label[text()='Industry'])[2]/following::div[1]")
	public WebElement industryNAICSCodeOptional;
	@TextType()
	@FindBy(xpath = "(//label[text()='NAICS Code (Optional)'])[2]/parent::div//input")
	public WebElement NAICSCodeOptional1;
	@TextType()
	@FindBy(xpath = "//span[text()='Corn farming']")
	public WebElement NAICSCodeOptionalValue1;
	@TextType()
	@FindBy(xpath = "(//label[text()='Industry'])[3]/following::div[1]")
	public WebElement industryNAICSCodeOptional1;
	@TextType()
	@FindBy(xpath = "//label[@for='approvedYes']/following::div[4]//input")
	public WebElement ECANumberLookup;
	@TextType()
	@FindBy(xpath = "//span[text()='4445-8JBNM']")
	public WebElement ECANumberValue;
	@TextType()
	@FindBy(xpath = "//label[text()='2.  Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/ancestor::div[@data-aura-class='cRegistryRadioGroup']/following-sibling::div//input")
	public WebElement ECANumberInput;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Yes']/preceding::span[1]")
	public WebElement additionalQuestionThreeYes;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Yes']/preceding::span[1]")
	public WebElement additionalQuestionThreeNo;
	@TextType()
	@FindBy(xpath = "//lightning-datepicker//input")
	public WebElement shortTermDate;
	@BooleanType()
	@FindBy(xpath = "//div[text()='Once you log a waste activity for this facility, this location information will no longer be editable. If you wish to edit this location information after logging a waste activity, you will need to contact Registry Support.']/following-sibling::div[1]//span[text()='This is a Canadian Address']")
	public WebElement locationCanadianAddress;
	@ChoiceListType()
	@FindBy(xpath = "//select[@name='State']")
	public WebElement locationState;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//label[text()='Zip Code']/following::div[1]//input")
	public WebElement locationZipCode;
	@TextType()
	@FindBy(xpath = "//label[text()='Generator Registration Number']/following::div[1]//input")
	public WebElement generatorRegistrationNumber;
	@BooleanType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[3]//span[text()='This is a Canadian Address']")
	public WebElement mailingCanadianAddress;
	@TextType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//label[text()='Zip Code']/following::div[1]//input")
	public WebElement mailingZipCode;
	@ChoiceListType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//select[@name='State']")
	public WebElement mailingState;
	@LinkType()
	@FindBy(xpath = "//a[text()='I am the primary Hazardous Waste Program contact']")
	public WebElement primaryHazardousWasteProgramContact;
	@LinkType()
	@FindBy(xpath = "//a[text()='I am the Alternate Contact']")
	public WebElement alternateContact;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Intermittently (less than once per year)']")
	public WebElement intermittently;
	@BooleanType()
	@FindBy(xpath = "//label[text()='1.  Is your facility an approved Ontario Liquid Industrial/Hazardous Waste Receiver facility?']/parent::div/following-sibling::div[1]/parent::div//span[text()='No']/preceding::span[1]")
	public WebElement additionalQuestionOneNo;
	@TextType()
	@FindBy(xpath = "//label[text()='2.  Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/parent::div/parent::div//span[text()='No']/preceding::span[1]")
	public WebElement additionalQuestionTwoNo;
	@TextType()
	@FindBy(xpath = "//label[text()='Generator Registration Number']/following::div[1]//span[@class='errorTextMessage']")
	public WebElement generatorRegistrationNumberDuplicateValidation;
	@LinkType()
	@FindBy(xpath = "//div[text()='Once you log a waste activity for this facility, this location information will no longer be editable. If you wish to edit this location information after logging a waste activity, you will need to contact Registry Support.']/following::div[1]//a[text()='Copy Business Address']")
	public WebElement locationCopyBusinessAddress;
	@LinkType()
	@FindBy(xpath = "//div[@id='Section_Facility_Mailing_Address']/following::div[2]//a[text()='Copy Business Address']")
	public WebElement mailingCopyBusinessAddress;
	@LinkType()
	@FindBy(xpath = "//a[text()='I am the primary Hazardous Waste Program contact']")
	public WebElement iAmThePrimaryHazardousWasteProgramContact;
	@BooleanType()
	@FindBy(xpath = "//span[text()='I do not wish to specify an alternate contact']/preceding::span[1]")
	public WebElement iDoNotWishToSpecifyAnAlternateContact;
	@ButtonType()
	@FindBy(xpath = "//label[text()='NAICS Code']/parent::div//button[@title='Remove']")
	public WebElement removeNAICSCode;
	@ButtonType()
	@FindBy(xpath = "(//label[text()='NAICS Code (Optional)'])[1]/parent::div//button[@title='Remove']")
	public WebElement removeNAICSCodeOptional1;
	@ButtonType()
	@FindBy(xpath = "(//label[text()='NAICS Code (Optional)'])[2]/parent::div//button[@title='Remove']")
	public WebElement removeNAICSCodeOptional2;
	@BooleanType()
	@FindBy(xpath = "//label[text()='3. Is your facility a contaminated facility located in Ontario, and all waste generated  is a result of activities carried out at the facility for the purpose of remediating contaminated soil or other contaminated materials located in, on, or under the site?']/parent::div/parent::div//span[text()='No']/preceding::span[1]")
	public WebElement additionalQuestionThreeNo1;
	@ChoiceListType()
	@FindBy(xpath = "//div[@id='Section_Facility_Location']/following::div[3]//span[text()='Province']/ancestor::div[1]//select")
	public WebElement province;
	@TextType()
	@FindBy(xpath = "//span[text()='One time']")
	public WebElement oneTime;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Deactivate Facility']")
	public WebElement deactivateFacility;
	@TextType()
	@FindBy(xpath = "//label[normalize-space(.)='Street']/parent::lightning-input/following-sibling::p")
	public WebElement generatorIdentificationValidation;
	@TextType()
	@FindBy(xpath = "//span[text()='My company is the operator of the waste generation facility.']")
	public WebElement myCompany;
	@TextType()
	@FindBy(xpath = "//span[text()='I am creating this facility on behalf of a generator who does not use the Registry.']")
	public WebElement behalfOfGenerator;
	@TextType()
	@FindBy(xpath = "//label[text()='Legal Business Name']/parent::div/parent::div//input")
	public WebElement legalBusinessName;
	@TextType()
	@FindBy(xpath = "//label[text()='Company Name']/parent::div/parent::div//input")
	public WebElement companyName;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Upload']")
	public WebElement Upload;
	
			
}
