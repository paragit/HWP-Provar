package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="RetrieveFacility"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class RetrieveFacility {

	@LinkType()
	@FindBy(xpath = "//a[text()='No, create a new facility']")
	public WebElement noAddANewFacility;
			
}
