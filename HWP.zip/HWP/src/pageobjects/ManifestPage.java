package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ManifestPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ManifestPage {

	@BooleanType()
	@FindBy(xpath = "//label/span[1]")
	public WebElement MyECASelect;
	@BooleanType()
	@FindBy(xpath = "//label/span[contains(@class,'slds-radio_faux')]")
	public WebElement SelectCarrierECA;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//input[@name='search' and @placeholder='Enter search terms here']")
	public WebElement Receivcer;
	@BooleanType()
	@FindBy(xpath = "//td//span/label/span[contains(@class,'slds-checkbox_faux')]")
	public WebElement WasteStreamSelect;
	@TextType()
	@FindBy(xpath = "//input[@id='input-757']")
	public WebElement ShippingName;
	@TextType()
	@JavascriptBy(jspath = "return document.querySelectorAll('lightning-input')[2].shadowRoot.querySelector('input')")
	public WebElement ShippingName1;
	@TextType()
	@JavascriptBy(jspath = "return document.querySelectorAll('lightning-input')[4].shadowRoot.querySelector('input')")
	public WebElement QuantityShipped;
	@ChoiceListType()
	@FindBy(xpath = "//div[4]/div[2]/div/div/div/div/div/div/div[contains(@class,'slds-form-element__control')]/div/select")
	public WebElement QtyShippedMeasure;
	@TextType()
	@JavascriptBy(jspath = "return document.querySelectorAll('lightning-input')[6].shadowRoot.querySelector('lightning-datepicker').shadowRoot.querySelector('input')")
	public WebElement SchShipDate;
	@TextType()
	@JavascriptBy(jspath = "return document.querySelectorAll('lightning-input')[7].shadowRoot.querySelector('lightning-datepicker').shadowRoot.querySelector('input')")
	public WebElement SchArrivalDate;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save']")
	public WebElement save;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Ready For Signatures']")
	public WebElement readyForSignatures;
	@ButtonType()
	@FindBy(xpath = "//div[1]/div[2]/button[normalize-space(.)='Sign Manifest' and @value='Generator']")
	public WebElement generatorSign;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Sign Manifest' and @value='Carrier']")
	public WebElement carrierSign;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Complete Drop-off' and contains(@class,'slds-button')]")
	public WebElement CompleteDropOff;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='Waste' and @data-tab-value='Waste' and @role='tab']")
	public WebElement wasteTab;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Accept' and @value='accept']")
	public WebElement acceptWaste;
	@TextType()
	@JavascriptBy(jspath = "return document.querySelectorAll('lightning-input')[1].shadowRoot.querySelector('input')")
	public WebElement AcceptQtyRec;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Sign Manifest']")
	public WebElement receiveSign;
	@TextType()
	@FindBy(xpath = "//strong[starts-with(normalize-space(.),'Completed')]")
	public WebElement StatusAssert;
	@BooleanType()
	@FindBy(xpath = "//td//span/label/span[contains(@class,'slds-radio_faux')]")
	public WebElement SelectReceiverECA;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Add Additional Carrier']")
	public WebElement addAdditionalCarrier;
	@TextType()
	@FindBy(xpath = "//lightning-formatted-number[contains(normalize-space(.),'$')]")
	public WebElement Fee_Value;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Refuse']")
	public WebElement refuse;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Shipping Name is required' and contains(@class,'errorTextMessage')]")
	public WebElement ShipNameValidate;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Quantity Shipped is required' and contains(@class,'errorTextMessage')]")
	public WebElement QtyShippedValidate;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Units is required' and contains(@class,'errorTextMessage')]")
	public WebElement UnitValidate;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='This field is required' and contains(@class,'errorTextMessage')]")
	public WebElement SchShipDate1;
	@TextType()
	@FindBy(xpath = "//*[contains(text(),'Status')]/following::*[contains(text(),'Awaiting')]")
	public WebElement StatusAssertSign;
	@TextType()
	@FindBy(xpath = "//span[contains(normalize-space(.),'manifest has') and contains(@class,'Header1')]")
	public WebElement CorrectMsgAssert;
	@ButtonType()
	@FindBy(xpath = "//div[1]/div[2]/button[contains(normalize-space(.),'Sign off on Corrections')]")
	public WebElement SignCorrections;
	@TextType()
	@FindBy(xpath = "//*[contains(text(),'Registry Fee Payment')]/following::*[starts-with(text(),'$')]")
	public WebElement FeeAssert;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Partially Refused By Receiver']")
	public WebElement WasteRefuseMsg;
	@TextType()
	@FindBy(xpath = "//*[contains(text(),'Some wastes on the manifest were refused by the receiver')]")
	public WebElement WasteRefusedMsg;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Edit Manifest']")
	public WebElement editManifest;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Add Waste']")
	public WebElement addWaste;
	@TextType()
	@FindBy(xpath = "//input[contains(@class,'slds-input') and @name='search' and @placeholder='Enter search terms here']")
	public WebElement WasteStreamSearch;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='Overview' and contains(@class,'slds-tabs_default__link')]")
	public WebElement overview;
	@TextType()
	@FindBy(xpath = "//input[contains(@class,'slds-input') and @name='search']")
	public WebElement CarrierSearch;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='Multiple Carriers Form']")
	public WebElement multipleCarriersForm;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='View LDR Notification Form']")
	public WebElement viewLDRNotificationForm;
	@ButtonType()
	@FindBy(xpath = "//button[@name='editShippingInfo']")
	public WebElement EditShippingInfo;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Edit' and @type='button']")
	public WebElement edit;
	@TextType()
	@FindBy(xpath = "//input[@id='input-1001']")
	public WebElement _ndQtyShipped;
	@TextType()
	@FindBy(xpath = "//span[normalize-space(.)='Upload']")
	public WebElement CarUpload;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Manage Waste']")
	public WebElement ManageWaste;
	@ButtonType()
	@FindBy(xpath = "//button[@name='addWasteStream' and @type='button']")
	public WebElement addWasteStream;
	@TextType()
	@FindBy(xpath = "//input[@name='search']")
	public WebElement WasteSearch;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Add Filters']")
	public WebElement filters;
	@TextType()
	@FindBy(xpath = "//tr[2]/td[1]/div/i")
	public WebElement Waste2;
	@BooleanType()
	@FindBy(xpath = "//label[normalize-space(.)='This manifest includes waste previously refused by a receiver']/span[1]")
	public WebElement RefusedWaste;
			
}
