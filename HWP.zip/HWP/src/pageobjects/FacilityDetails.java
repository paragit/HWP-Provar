package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="FacilityDetails"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class FacilityDetails {

	@TextType()
	@FindBy(xpath = "//div[text()='Facility Name']/following::div[1]")
	public WebElement facilityName;
	@TextType()
	@FindBy(xpath = "//div[text()='Generator Number']/following::div[1]")
	public WebElement generatorNumber;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Short-Term Storage']/preceding::span[1]")
	public WebElement shortTermStorage;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//span[text()='Processing']/preceding::span[1]")
	public WebElement processing;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Long-Term Storage']/preceding::span[1]")
	public WebElement longTermStorage;
	@BooleanType()
	@FindBy(xpath = "//span[text()='Disposal']/preceding::span[1]")
	public WebElement disposal;
			
}
