package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="DeactivateFacilityPopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class DeactivateFacilityPopUp {

	@ButtonType()
	@FindBy(xpath = "//button[text()='Cancel']")
	public WebElement cancel;
	@TextType()
	@FindBy(xpath = "//span[text()='All hazardous waste has been removed from this Facility, and that this Facility is no longer generating hazardous waste']")
	public WebElement allHazardousWasteHasBeenRemoved;
	@TextType()
	@FindBy(xpath = "//input[@type='text']")
	public WebElement deactivationDate;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Deactivate']")
	public WebElement deactivate;
	@TextType()
	@FindBy(xpath = "//span[@class='errorTextMessage']")
	public WebElement deactivationDateValidation;
	@TextType()
	@FindBy(xpath = "//span[text()='Going forward, another company (an Authorized Generator Delegate) will be responsible for managing this Facility’s waste activity reporting']")
	public WebElement AGDResponsible;
			
}
