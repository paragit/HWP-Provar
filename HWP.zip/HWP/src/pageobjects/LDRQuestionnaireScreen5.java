package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRQuestionnaireScreen5"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRQuestionnaireScreen5 {

	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//label[text()='OWRA Facility']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement OWRAFacilityValidation;
	@TextType()
	@FindBy(xpath = "//label[text()='Incineration Facility']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement incinerationFacility;
	@TextType()
	@FindBy(xpath = "//label[text()='Waste-derived fuel site']/parent::div/parent::div/following-sibling::div//span[@class='errorTextMessage']")
	public WebElement wasteDerivedFuelSite;
	@TextType()
	@FindBy(xpath = "//input[@id='owraFacilityYes']")
	public WebElement OWRAFacilityYes;
	@TextType()
	@FindBy(xpath = "//input[@type='text']")
	public WebElement OWRAFacilityECANumber;
	@ButtonType()
	@FindBy(xpath = "//button[@name='owraFacilityECAs']")
	public WebElement addAnotherECANumberOWRAFacility;
	@TextType()
	@FindBy(xpath = "//input[@id='input-118']")
	public WebElement OWRAFacilityECANumber1;
	@ButtonType()
	@FindBy(xpath = "//button[@class='slds-button deleteButton']")
	public WebElement removeECANumberOWRA;
	@TextType()
	@FindBy(xpath = "//input[@id='owraFacilityNo']")
	public WebElement OWRAFacilityNo;
	@TextType()
	@FindBy(xpath = "//input[@id='incinerationFacilityNo']")
	public WebElement incinerationFacilityNo;
	@TextType()
	@FindBy(xpath = "//input[@id='wasteDerivedFuelSiteNo']")
	public WebElement wasteDerivedFuelSiteNo;
	@TextType()
	@FindBy(xpath = "//input[@id='incinerationFacilityYes']")
	public WebElement incinerationFacilityYes;
	@TextType()
	@FindBy(xpath = "//input[@id='input-122']")
	public WebElement incinerationFacilityECANumber;
	@TextType()
	@FindBy(xpath = "//input[@id='wasteDerivedFuelSiteYes']")
	public WebElement wasteDerviedFuelSiteYes;
	@TextType()
	@FindBy(xpath = "//input[@id='input-124']")
	public WebElement wasteDerivedFuelSiteECANumber;
	@LinkType()
	@FindBy(xpath = "//div[@id='modal-content-id-1']//a[normalize-space(.)='Cancel']")
	public WebElement cancel;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='< Back']")
	public WebElement back;
			
}
