package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ECADetails"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ECADetails {

	@TextType()
	@FindBy(xpath = "//div[contains(text(),'ECA Number')]/following::div[1][contains(@class,'boldText')]")
	public WebElement ECANumber;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Role')]/following::div[1]")
	public WebElement role;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Company Name')]/following::div[1]")
	public WebElement companyName;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Mailing Address')]/following::div[1]/div[1]//div[1]")
	public WebElement mailingAddress1;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Mailing Address')]/following::div[1]/div[1]//div[2]")
	public WebElement mailingAddress2;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Mailing Address')]/following::div[1]/div[1]//div[3]")
	public WebElement mailingAddress3;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Email')]/following::div[1][contains(@class,'boldText')]")
	public WebElement email;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Phone Number')]/following::div[1][contains(@class,'boldText')]")
	public WebElement phoneNumber;
	@TextType()
	@FindBy(xpath = "//div[contains(text(),'Phone Extension')]/following::div[1][contains(@class,'boldText')]")
	public WebElement phoneExtension;
	@TextType()
	@FindBy(xpath = "//div[@id='row'][1]/div[@id='col']")
	public WebElement wasteClass1;
	@TextType()
	@FindBy(xpath = "//div[@id='row'][2]/div[@id='col']")
	public WebElement wasteClass2;
	@TextType()
	@FindBy(xpath = "//div[@id='row'][3]/div[@id='col']")
	public WebElement wasteClass3;
	@TextType()
	@FindBy(xpath = "//div[@id='row'][4]/div[@id='col']")
	public WebElement wasteClass4;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Edit']")
	public WebElement edit;
			
}
