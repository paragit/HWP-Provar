package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="RoleSelectionPopUp"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class RoleSelectionPopUp {

	@TextType()
	@FindBy(xpath = "//div[contains(@class,'ModalHeader')]//h2")
	public WebElement roleSelectionHeader;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'ModalSubHeader')]/div[1]")
	public WebElement roleSelectionSubHeader;
	@TextType()
	@FindBy(xpath = "//span[text()='Generator']")
	public WebElement generator;
	@BooleanType()
	@FindBy(xpath = "//div[contains(text(),'I confirm')]/parent::div//input")
	public WebElement disabledConfirmationCheckbox;
	@BooleanType()
	@FindBy(xpath = "//div[contains(text(),'I confirm')]/parent::div//input/parent::span")
	public WebElement confirmCheckbox;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,'ConfirmationBox')]//div[2]")
	public WebElement confirmationBoxText;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='Cancel']")
	public WebElement cancel;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Done']")
	public WebElement done;
	@TextType()
	@FindBy(xpath = "//span[text()='Carrier']/preceding::span[1]")
	public WebElement carrier;
	@TextType()
	@FindBy(xpath = "//span[text()='Receiver']/preceding::span[1]")
	public WebElement receiver;
	@TextType()
	@FindBy(xpath = "//span[text()='Authorized Generator Delegate']")
	public WebElement authorizedGeneratorDelegate;
			
}
