package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRQuestionnaireScreen4"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRQuestionnaireScreen4 {

	@TextType()
	@FindBy(xpath = "//span[text()='Yes, enter Tonnage Fee Exempt Recycling Facilities ECA Number']")
	public WebElement Yes;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//span[@class='errorTextMessage']")
	public WebElement YesValidation;
	@TextType()
	@FindBy(xpath = "//input[@type='text']")
	public WebElement ECANumber;
	@TextType()
	@FindBy(xpath = "//span[text()='No']")
	public WebElement No;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='< Back']")
	public WebElement back;
			
}
