package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="SelectWasteStream"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class SelectWasteStream {

	@BooleanType()
	@FindBy(xpath = "//tr[1]//lightning-input[1]")
	public WebElement selectWasteStream;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
			
}
