package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRQuestionnaireScreen2"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRQuestionnaireScreen2 {

	@TextType()
	@FindBy(xpath = "//input[@id='smallQuantityGeneratorYes']")
	public WebElement Yes;
	@TextType()
	@FindBy(xpath = "//input[@type='text']")
	public WebElement estimatedTotalQuantity;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//input[@id='smallQuantityGeneratorNo']")
	public WebElement No;
			
}
