package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ViewFacility"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ViewFacility {

	@TextType()
	@FindBy(xpath = "//div[text()='Facility Name']/following::div[1]")
	public WebElement viewFacilityName;
	@ButtonType()
	@FindBy(xpath = "//div[text()='Facility Name']/parent::div//button")
	public WebElement editFacilityName;
	@TextType()
	@FindBy(xpath = "//div[text()='How long will this Facility being generating waste?']/following::div[1]//div[@class='boldText']")
	public WebElement howLongActivity;
	@TextType()
	@FindBy(xpath = "//div[text()='How often will this Facility be shipping waste off site?']/following::div[1]")
	public WebElement howOftenActivity;
	@ButtonType()
	@FindBy(xpath = "//div[text()='How long will this Facility being generating waste?']/parent::div//button[text()='Edit']")
	public WebElement editWasteGenerationActivity;
	@TextType()
	@FindBy(xpath = "//div[text()='Community']/following::div[1]")
	public WebElement community;
	@TextType()
	@FindBy(xpath = "//div[text()='Location']/parent::div/div[text()='Address']/following::div[1]/div[1]//div[1]")
	public WebElement locationAddress1;
	@TextType()
	@FindBy(xpath = "//div[text()='Location']/parent::div/div[text()='Address']/following::div[1]/div[1]/div[2]")
	public WebElement locationAddress2;
	@TextType()
	@FindBy(xpath = "//div[text()='Location']/parent::div/div[text()='Address']/following::div[1]/div[1]/div[3]")
	public WebElement locationAddress3;
	@TextType()
	@FindBy(xpath = "//div[text()='Latitude']/following::div[1]")
	public WebElement latitiude;
	@TextType()
	@FindBy(xpath = "//div[text()='Longitude']/following::div[1]")
	public WebElement longitude;
	@TextType()
	@FindBy(xpath = "//div[text()='Description']/following::div[1]")
	public WebElement facilityAddressDescription;
	@TextType()
	@FindBy(xpath = "//div[text()='Mailing Address']/parent::div/div[text()='Address']/following::div[1]/div[1]/div[1]")
	public WebElement mailingAddress1;
	@TextType()
	@FindBy(xpath = "//div[text()='Mailing Address']/parent::div/div[text()='Address']/following::div[1]/div[1]/div[2]")
	public WebElement mailingAddress2;
	@TextType()
	@FindBy(xpath = "//div[text()='Mailing Address']/parent::div/div[text()='Address']/following::div[1]/div[1]/div[3]")
	public WebElement mailingAddress3;
	@ButtonType()
	@FindBy(xpath = "//div[text()='Mailing Address']/parent::div/div[text()='Address']/parent::div/parent::div/following-sibling::div//button[text()='Edit']")
	public WebElement editFacilityAddress;
	@ButtonType()
	@FindBy(xpath = "//button[@value='Section_Primary_Contact']")
	public WebElement editFacilityContact;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[1][text()='Name']/following::div[1]")
	public WebElement primaryContactName;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[3][text()='Job Title']/following::div[1]")
	public WebElement primaryContactJobTitle;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[5][text()='Email']/following::div[1]")
	public WebElement primaryContactEmail;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[7][text()='Primary Phone Number']/following::div[1]")
	public WebElement primaryContactPrimaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[9][text()='Phone Extension']/following::div[1]")
	public WebElement primaryContactPhoneExtension;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[11][text()='Secondary Phone Number']/following::div[1]")
	public WebElement primaryContactSecondaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Primary Contact']/following::div[13][text()='Phone Extension']/following::div[1]")
	public WebElement primaryContactSecondaryPhoneExtension;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[1][text()='Name']/following::div[1]")
	public WebElement alternateContactName;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[3][text()='Job Title']/following::div[1]")
	public WebElement alternateContactJobTitle;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[5][text()='Email']/following::div[1]")
	public WebElement alternateContactEmail;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[7][text()='Primary Phone Number']/following::div[1]")
	public WebElement alternateContactPrimaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[9][text()='Phone Extension']/following::div[1]")
	public WebElement alternateContactPhoneExtension;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[11][text()='Secondary Phone Number']/following::div[1]")
	public WebElement alternateContactSecondaryPhoneNumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Alternate Contact']/following::div[13][text()='Phone Extension']/following::div[1]")
	public WebElement alternateContactSecondaryPhoneExtension;
	@TextType()
	@FindBy(xpath = "//div[normalize-space(.)='111110']")
	public WebElement naicsCode;
	@TextType()
	@FindBy(xpath = "//div[text()='NAICS Code']/parent::div//div[text()='Industry']/following::div[1]")
	public WebElement industryNAICSCode;
	@TextType()
	@FindBy(xpath = "//div[text()='NAICS Code']/parent::div/parent::div/following-sibling::div[1]//div[text()='NAICS Code (Optional)']/following::div[1]")
	public WebElement NAICSCodeOptional1;
	@TextType()
	@FindBy(xpath = "//div[text()='NAICS Code']/parent::div/parent::div/following-sibling::div[1]//div[text()='Industry']/following::div[1]")
	public WebElement industryNAICSCodeOptional1;
	@TextType()
	@FindBy(xpath = "//div[text()='NAICS Code']/parent::div/parent::div/following-sibling::div[2]//div[text()='NAICS Code (Optional)']/following::div[1]")
	public WebElement NAICSCodeOptional2;
	@TextType()
	@FindBy(xpath = "//div[text()='NAICS Code']/parent::div/parent::div/following-sibling::div[2]//div[text()='Industry']/following::div[1]")
	public WebElement industryNAICSCodeOptional2;
	@TextType()
	@FindBy(xpath = "//div[text()='Is your facility an approved Ontario Liquid Industrial/Hazardous Waste Receiver facility?']/following::div[1]")
	public WebElement additionalQuestionOne;
	@TextType()
	@FindBy(xpath = "//div[text()='Is your facility an approved Ontario Liquid Industrial/Hazardous Waste Receiver facility?']/parent::div//div[text()='Corresponding ECA Number']/following::div[1]")
	public WebElement additionalQuestionOneECANumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/following::div[1]")
	public WebElement additionalQuestionTwo;
	@TextType()
	@FindBy(xpath = "//div[text()='Is your facility a Municipal Hazardous or Special Waste depot operated or exclusively for a municipality or the Crown?']/parent::div//div[text()='Corresponding ECA Number']/following::div[1]")
	public WebElement additionalQuestionTwoECANumber;
	@TextType()
	@FindBy(xpath = "//div[text()='Is your facility a contaminated facility and all waste results from activities carried on at the facility for the purpose of remediating contaminated soil or other contaminated materials located on, in, or under the site?']/following::div[1]")
	public WebElement additionalQuestionThree;
	@ButtonType()
	@FindBy(xpath = "//button[@value='Section_Additional_Information']")
	public WebElement editAdditionalInformation;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Deactivate Facility']")
	public WebElement deactivateFacility;
	@TextType()
	@FindBy(xpath = "//div[@data-aura-class='cRegistryHWPFacilityView'][1]//div[contains(@class,'boldText')]")
	public WebElement facilityInactive;
	@TextType()
	@FindBy(xpath = "//div[text()='Deactivation Date']/following::div[contains(@class,'boldText')][1]")
	public WebElement deactivationDate;
	@TextType()
	@FindBy(xpath = "//div[text()='Deactivation Reason']/following::div[contains(@class,'boldText')][1]")
	public WebElement deactivationReason;
	@ButtonType()
	@FindBy(xpath = "//div[text()='Deactivation Date']/parent::div//button")
	public WebElement editDeactivationDetails;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Reactivate']")
	public WebElement reactivate;
	@TextType()
	@FindBy(xpath = "//div[text()='Generator Details']/following::div[1]")
	public WebElement generatorDetails;
	@TextType()
	@FindBy(xpath = "//div[text()='Legal Business Name']/following::div[1]")
	public WebElement legalBusinessName;
	@TextType()
	@FindBy(xpath = "//div[text()='Company Name']/following::div[1]")
	public WebElement companyName;
	@ButtonType()
	@FindBy(xpath = "//div[text()='Generator Details']/parent::div/parent::div/parent::div//button[text()='Edit']")
	public WebElement editGeneratorIdentification;
	@LinkType()
	@FindBy(xpath = "//a[text()='On-site Waste Activities']")
	public WebElement onSiteWasteActivitiesAccordion;
	@LinkType()
	@FindBy(xpath = "//a[text()='Log On-site Waste Activity']")
	public WebElement logOnSiteWasteActivity;
	
	
	
	
	
			
}
