package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="DashboardPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class DashboardPage {

	@LinkType()
	@FindBy(xpath = "//a[text()='Switch Programs']")
	public WebElement switchPrograms;
	@LinkType()
	@FindBy(xpath = "//a[contains(text(),'Facilities')]")
	public WebElement facilitiesTab;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Add Facility']")
	public WebElement addFacility;
	@LinkType()
	@FindBy(xpath = "//a[text()='Waste Streams']")
	public WebElement wasteStreams;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Add Waste Stream']")
	public WebElement addWasteStream;
	@LinkType()
	@FindBy(xpath = "//a[text()='Add Roles']")
	public WebElement addRoles;
	@LinkType()
	@FindBy(xpath = "//a[text()='ECA Numbers']")
	public WebElement ECANumbersTab;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Link ECA Numbers']")
	public WebElement linkECANumbers;
	@TextType()
	@FindBy(xpath = "//input[@type='text']")
	public WebElement searchECANumber;
	@LinkType()
	@FindBy(xpath = "//a[text()='View']")
	public WebElement viewECANumbers;
	@LinkType()
	@FindBy(xpath = "//tr[1]//a[text()='View']")
	public WebElement viewWasteStream;
	@LinkType()
	@FindBy(xpath = "//tr[1]//a[text()='View']")
	public WebElement viewFaciilty;
	@TextType()
	@FindBy(xpath = "//div[@class='dropdown-toggle']")
	public WebElement userMenu;
	@LinkType()
	@FindBy(xpath = "//a[text()='Manage Users']")
	public WebElement manageUsers;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='New Manifest']")
	public WebElement newManifest;
	@LinkType()
	@FindBy(xpath = "//a[normalize-space(.)='New Manifest']")
	public WebElement newManifest1;
	@BooleanType()
	@FindBy(xpath = "//label/span[@class='slds-radio_faux']")
	public WebElement selectCarrier;
	@BooleanType()
	@FindBy(xpath = "//td//span/label/span[1]")
	public WebElement selectCarrier1;
	@ButtonType()
	@FindBy(xpath = "//div[@id='modal-content-id-1']//button[normalize-space(.)='Save']")
	public WebElement save;
	
			
}
