package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ReceiverSignPage"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class ReceiverSignPage {

	@BooleanType()
	@FindBy(xpath = "//div[@id='modal-content-id-1']//label/span[contains(@class,'slds-checkbox_faux')]")
	public WebElement ReceiverConfirm;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='Confirm']")
	public WebElement confirm;
			
}
