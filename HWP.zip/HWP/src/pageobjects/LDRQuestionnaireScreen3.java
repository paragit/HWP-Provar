package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="LDRQuestionnaireScreen3"                                
     , summary=""
     , relativeUrl=""
     , connection="RegistryPortal"
     )             
public class LDRQuestionnaireScreen3 {

	@TextType()
	@FindBy(xpath = "//span[text()='Waste stream is a MHSW exempt under section 81 of Regulation 347.']")
	public WebElement wasteStreamMHSWExempt;
	@TextType()
	@FindBy(xpath = "//label[text()='MHSW Depot ESC Number']/following::div[1]//input")
	public WebElement MHSWDepotNumber;
	@ButtonType()
	@FindBy(xpath = "//button[text()='Save & Next >']")
	public WebElement saveAndNext;
	@TextType()
	@FindBy(xpath = "//span[@class='errorTextMessage']")
	public WebElement MHSWDepotNumberValidation;
	@TextType()
	@FindBy(xpath = "//span[text()='Not a MHSW exempt under Section 81 of Regulation 347 nor a SQG waste in a sealed container received at your transfer station that is exempt under section 80 of Regulation 347.']")
	public WebElement notMHSWExempt;
	@ButtonType()
	@FindBy(xpath = "//button[normalize-space(.)='< Back']")
	public WebElement back;
			
}
